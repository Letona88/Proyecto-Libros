from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from sales import views
from django.conf.urls import url

#Rutas para dos únicas funciones: Mostrar y crear.
urlpatterns=[
    path('', views.index, name='sale'),
    path('create/', views.create,  name='create_sale'),
]