from django.shortcuts import render, redirect
from sales import controller
from django.contrib import messages
import datetime

# Vista para poder mostrar las ventas hechas.
def index(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_sale(request)
    return render(request, 'sale/index.html', cr[0])

#Vista para crear una nueva venta.
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.create_sale(request)
        if cr:
            messages.success(request, 'Venta registrada correctamente!')
        else: 
            messages.error(request, 'La cantidad de libros es mayor a la que se dispone actualmente')
        return redirect('sale') 

    return render(request, 'sale/index.html')
