from django.db import models
from products.models import Product
from invoices.models import Invoice

class Sale(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=False, blank=False)
    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, null=True, blank=True)
    date_sale = models.DateField(auto_now_add=True, null=True, blank=True)
    quantity = models.IntegerField(null=True, blank=True)
    total = models.DecimalField(null=True, blank=True, max_digits=5, decimal_places=2)