from sales.models import Sale
from products.models import Product
from inventories.models import Inventory
from invoices.models import Invoice
from clients.models import Client
from django.core.files.storage import FileSystemStorage
import datetime

#funcion para poder obtener todas la ventas.
def get_sale(request):
    response = []
    sales = Sale.objects.all()
    products = Product.objects.all()
    invoices = Invoice.objects.all()
    clients = Client.objects.all()

    response.append({
        "sales":sales,
        "products":products,
        "invoices":invoices,
        "clients":clients
    })

    return response

#Funcion para crear un registro de ventas.
def create_sale(request):
    data=request.POST
    
    date_sale=data.get('date')
    date_sale=datetime.datetime.strptime(date_sale, "%m/%d/%Y").strftime("%Y-%m-%d")
    client = Client.objects.get(id=data.get('client'))
    product = Product.objects.get(id=data.get('product'))
    quantity = data.get('quantity')

    #Verificacion si la cantidad de libros comprados es mayor a la existencia de dicho libro
    if int(product.quanty) < int(quantity):
        return False
    
    #si esta venta pertenece a una factura diferente se creará un nuevo registro
    #de lo contrario se obtiene el registro de la factura ya hecha previamente.
    if data.get('new_sale') != None:
        invoice = Invoice(
            date_action=date_sale,
            client=client
        )
        invoice.save()
    else:
        invoice = Invoice.objects.get(id=data.get('invoice'))

    new_sale=Sale(
        product=product, 
        invoice=invoice,
        date_sale=date_sale,
        quantity=quantity,
        total=float(quantity) * float(product.price)
    )
    new_sale.save()
    #se modifica la cantidad de existencias de un producto
    product.quanty-=int(quantity)

    product.save()

    #Se crea un registro en el inventario
    new_inventary=Inventory(
        product=product,
        content_object=new_sale,
        date_action=date_sale,
        quantity=quantity,
        total=float(quantity)*float(product.price)
    )

    new_inventary.save()

    if new_sale:
        return True
    else:
        return False
