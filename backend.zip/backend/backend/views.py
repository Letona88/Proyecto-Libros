from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login, logout as auth_logout
from products.models import Product
from purchases.models import Purchase
from sales.models import Sale
from clients.models import Client
from invoices.models import Invoice

#view que llevará al dashboar de la aplicación se hace una condición, si está logueado se mandará al dashboard
#administrativo, de lo contrario a la vista dónde uno pueda loguearse.
def dashboard(request):
    if request.user.is_authenticated:
        products = Product.objects.all()
        purchases = Purchase.objects.all()
        sales = Sale.objects.all()
        clients=Client.objects.all()
        invoices=Invoice.objects.all()
        data={
            'products':products.count(),
            'purchases':purchases.count(),
            'sales':sales.count(),
            'clients':clients,
            'invoices':invoices
        }
        return render(request, 'dashboard.html', data)
    products = Product.objects.all()
    data={
        'products':products
    }
    return render(request, 'index.html', data)

#View que servirá para autentificare, si desde el template no se hace un POST se mandará al template de login
#de lo contrario tratará de loguearse y si es exitoso se accederá al dashboard administrativo.
def login(request):
    if request.method == 'POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('dashboard')
    return render(request, 'login/index.html')

#View que servirá para desloguarse y luego ir al login.
def logout(request):
    auth_logout(request)
    return redirect('login')

#View para mostrar a los integrantes del proyecto
def members(request):
    return render(request, 'members.html')
