from django.contrib import admin
from django.urls import path
from django.conf.urls import include, url
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic.base import RedirectView

from backend import views

#Dentro de la carpeta backend se contendrán todas la rutas para que se pueda acceder a las diferentes funciones
#Cuando hay más de una ruta que aputa hacia una funcion se puede utilizar la propiedad include de diango que
#nos servirá para adjuntar varias rutas dentro de una misma ruta base
#por ejemplo:
#productos/ (url base de productos)
#productos/agregar (url base de productos + ruta para agregar un nuevo producto)

urlpatterns = [
    url('admin/', admin.site.urls),
    url(r'^$', views.dashboard, name='dashboard'),
    url(r'^login', views.login, name='login'),
    url(r'^members', views.members, name='members'),
    url(r'^logout', views.logout, name='logout'),
    path(r'product/', include('products.urls')),
    path(r'client/', include('clients.urls')),
    path(r'purchase/', include('purchases.urls')),
    path(r'sale/', include('sales.urls')),
    path(r'inventory/', include('inventories.urls')),
    path(r'invoice/', include('invoices.urls')),
    url(r'^favicon\.ico$',RedirectView.as_view(url='/static/images/favicon.ico')),
]
#Esta ruta es opcional si nuestro sistema manejará imagenes, en nuestro casi si.
if settings.DEBUG:
    urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

urlpatterns+=static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)