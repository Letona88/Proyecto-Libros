from inventories.models import Inventory

def get_data(request):
    response = []
    inventories = Inventory.objects.all()
    debe = 0.00
    haber = 0.00
    for inventory in inventories:
        if inventory.content_type.app_label == "sales":
            debe += float(inventory.content_object.total)
        else:
            haber += float(inventory.content_object.total)


    response.append({
        "inventories":inventories,
        "total_debe":debe,
        "total_haber":haber
    })

    return response