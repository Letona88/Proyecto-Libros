from django.shortcuts import render
from inventories import controller
from django.http import HttpResponse
from inventories.models import Inventory
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm
from reportlab.lib.colors import pink, green, brown, white
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Table, TableStyle, Image
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
import datetime
from datetime import date

from backend.utils import render_to_pdf

# Vista para mostrar el inventario.
def data(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_data(request)
    return render(request, 'inventory/index.html', cr[0])

#Vista para generar un inventario en formato pdf
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    #Se obtiene el rango de fecha para traer el registro de inventario con un rango.
    start_date=request.POST.get('start-date')
    start_date = datetime.datetime.strptime(start_date, "%m/%d/%Y").strftime("%Y-%m-%d")
    end_date=request.POST.get('end-date')
    end_date = datetime.datetime.strptime(end_date, "%m/%d/%Y").strftime("%Y-%m-%d")
    inventories=Inventory.objects.filter(date_action__range=[str(start_date), str(end_date)])
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition']='attachment; filename=inventory.pdf'
    buffer=BytesIO()
    c = canvas.Canvas(buffer)


    #Rectangulo en el lado izquierdo
    c.setFillColor(HexColor(0x3A8057))
    c.rect(-0.2*inch,-0.2*inch,1*inch,20*inch, stroke=0, fill=1)

    c.setLineWidth(.3)
    c.setFillColor(HexColor(0x254233))
    c.setFont('Helvetica-Bold',22)
    c.drawString(75,750,'Space Book')
    c.setFillColor(HexColor(0x2B2B2B))
    c.setFont('Helvetica',12)
    c.drawString(75,715,'Movimientos diarios')
    c.line(75,705,560,705)
    c.setFont('Helvetica',12)
    c.drawString(75,685,'De fecha: '+start_date)
    c.setFont('Helvetica',12)
    c.drawString(75,665,'A fecha: '+end_date)
    c.setFont('Helvetica-Bold', 12)
    c.drawString(480,750,str(date.today()))
    c.line(460,747,560,747)
    
    #Estilos para la tabla
    styles=getSampleStyleSheet()
    styleBH=styles["Normal"]
    styleBH.alignment=TA_CENTER
    styleBH.fontSize=10

    #Header de la tabla
    codigo=Paragraph('''No.''',styleBH)
    movimiento=Paragraph('''Movimiento''',styleBH)
    debe=Paragraph('''Columna 1''',styleBH)
    haber=Paragraph('''Columna 2''',styleBH)

    info=[]
    info.append([codigo,movimiento, debe, haber])

    styleN=styles["BodyText"]
    styleN.alignment=TA_CENTER
    styleN.fontSize=7

    high=630
    code = 1
    total_sales=0.00
    total_purchases=0.00
    #información de la tabla
    for inventory in inventories:
        if inventory.content_type.app_label=="sales":
            clnt=inventory.content_object.invoice.client
            c_o=inventory.content_object
            this_inventory=[
                str(code),
                "Se vendió "+ str(c_o.quantity) + " libros("+ c_o.product.title +")",
                "",
                "Q "+str(c_o.total)
                ]
            info.append(this_inventory)
            total_sales+=float(c_o.total)
        else:
            c_o=inventory.content_object
            this_inventory=[
                str(code),
                "Se compró "+ str(c_o.quantity) + " libros("+ c_o.product.title+")",
                "Q "+str(c_o.total),
                ""
                ]
            info.append(this_inventory)
            total_purchases+=float(c_o.total)
        code+=1
        high-=18
    info.append([
        str(code),
        "TOTALES",
        "Q "+str(total_purchases),
        "Q "+str(total_sales)
    ])
    high-=18

    width,heigth=A4

    table = Table(info, colWidths=[1.9*cm, 9*cm, 3*cm, 3*cm])
    table.setStyle(TableStyle([
        ('INNERGRID', (0,0),(-1,-1), 0.25, HexColor(0x040001)),
        ('BOX', (0,0), (-1,-1), 0.25, HexColor(0x040001))
    ]))
    table.wrapOn(c, width, heigth)
    table.drawOn(c, 77, high)
    c.showPage()

    c.save()
    pdf=buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response
