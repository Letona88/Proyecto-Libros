from django.db import models
from products.models import Product
from django.contrib.contenttypes.models import ContentType
from django.contrib.contenttypes.fields import GenericForeignKey

class Inventory(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE, null=False, blank=False)
    #Content_type, object_id y content_object nos servirán para relacionar este modelo con: ventas o compras
    #esto con el fin de no tener que crear doble registro uno para cada modelo.
    content_type = models.ForeignKey(ContentType, related_name="content_type_timelines", on_delete=models.CASCADE, null=True, blank=True)
    object_id = models.PositiveIntegerField( null=True, blank=True)
    content_object = GenericForeignKey('content_type', 'object_id')
    date_action = models.DateField(auto_now_add=True, null=True, blank=True)
    quantity = models.IntegerField(null=True, blank=True)
    total = models.DecimalField(null=True, blank=True, max_digits=5, decimal_places=2)