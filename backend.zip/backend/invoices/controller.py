from invoices.models import Invoice

def get_invoice(request):
    response = []
    invoices = Invoice.objects.all()


    response.append({
        "invoices":invoices,
    })

    return response