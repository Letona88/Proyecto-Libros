from django.shortcuts import render, redirect
from invoices import controller
from django.http import HttpResponse
from invoices.models import Invoice
from django.contrib import messages
from purchases.models import Purchase
import datetime
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import inch, cm
from reportlab.lib.colors import pink, green, brown, white
from reportlab.lib.colors import HexColor
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import Paragraph, Table, TableStyle, Image
from reportlab.lib.enums import TA_CENTER
from reportlab.lib import colors
import datetime
from datetime import date

# Vista para mostrar una factura.
def index(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_invoice(request)
    return render(request, 'invoice/index.html', cr[0])

#Vista para poder generar una factura en formato pdf.
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    invoice_id=request.POST.get('invoice')
    invoice=Invoice.objects.get(pk=invoice_id)
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition']='attachment; filename=invoice.pdf'
    buffer=BytesIO()
    c = canvas.Canvas(buffer)

    #Rectangulo en el lado izquierdo
    c.setFillColor(HexColor(0x2DB1D2))
    c.rect(-0.2*inch,-0.2*inch,1*inch,20*inch, stroke=0, fill=1)

    c.setLineWidth(.3)
    c.setFillColor(HexColor(0x3088E1))
    c.setFont('Helvetica-Bold',22)
    c.drawString(75,750,'Space Book')
    c.setFillColor(HexColor(0x2B2B2B))
    c.setFont('Helvetica',12)
    c.drawString(75,715,'Factura')
    c.line(75,705,560,705)
    c.setFont('Helvetica',12)
    c.drawString(75,685,'A nombre de: ')
    c.setFont('Helvetica',12)
    c.drawString(75,665,invoice.client.first_name + " " +invoice.client.last_name)
    c.setFont('Helvetica-Bold', 12)
    c.drawString(480,750,str(date.today()))
    c.line(460,747,560,747)
    
    #Estilos para la tabla
    styles=getSampleStyleSheet()
    styleBH=styles["Normal"]
    styleBH.alignment=TA_CENTER
    styleBH.fontSize=10

    #Header de la tabla
    codigo=Paragraph('''No.''',styleBH)
    producto=Paragraph('''Producto''',styleBH)
    cantidad=Paragraph('''Cantidad''',styleBH)
    precio=Paragraph('''Precio''',styleBH)
    subtotal=Paragraph('''Subtotal''',styleBH)

    info=[]
    info.append([codigo,producto, cantidad, precio,subtotal])

    styleN=styles["BodyText"]
    styleN.alignment=TA_CENTER
    styleN.fontSize=7

    high=630
    code = 1
    total_sale=0.00
    total_quantity=0
    sales = invoice.sale_set.all()
    #información de la tabla
    for sale in sales:
        this_sale=[
            str(code),
            str(sale.product.title),
            str(sale.quantity),
            "Q "+str(sale.product.price),
            "Q "+str(sale.total),
            ]
        info.append(this_sale)
        total_sale+=float(sale.total)
        total_quantity+=int(sale.quantity)
        code+=1
        high-=18
    info.append([
        str(code),
        "TOTAL",
        str(total_quantity),
        "",
        "Q "+str(total_sale),
    ])
    high-=18

    width,heigth=A4

    table = Table(info, colWidths=[1*cm, 8.5*cm, 2.5*cm, 2.5*cm, 2.5*cm])
    table.setStyle(TableStyle([
        ('INNERGRID', (0,0),(-1,-1), 0.25, HexColor(0x040001)),
        ('BOX', (0,0), (-1,-1), 0.25, HexColor(0x040001))
    ]))
    table.wrapOn(c, width, heigth)
    table.drawOn(c, 77, high)
    c.showPage()

    c.save()
    pdf=buffer.getvalue()
    buffer.close()
    response.write(pdf)
    return response

