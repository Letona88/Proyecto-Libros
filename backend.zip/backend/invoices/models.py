from django.db import models
from clients.models import Client

class Invoice(models.Model):
    date_action = models.DateField(auto_now_add=True, null=False, blank=False)
    client = models.ForeignKey(Client, on_delete=models.CASCADE, null=False, blank=False)