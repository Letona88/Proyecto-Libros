from django.shortcuts import render, redirect
from clients import controller
from django.contrib import messages
from clients.models import Client
import datetime

#Vista para mostrar en el template todos a todos los cliente registrados
def index(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_clients(request)
    return render(request, 'client/index.html', cr[0])

#Vista para poder crear un cliente o mostrar el formulario para crear un cliente.
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.create_client(request)
        if cr:
            messages.success(request, '¡Cliente registrado correctamente!')
        else: 
            messages.error(request, '¡Error al registrar al cliente!')
        return redirect('client') 

    return render(request, 'client/create.html')

#Vista para poder editar un cliente o mostrar el formulario para editar un cliente.
def edit(request, id_client):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.edit_client(request,id_client)
        if cr:
            messages.success(request, '¡Datos del cliente editado correctamente!')
        else: 
            messages.error(request, '¡Error al editar al cliente!')
        return redirect('client')
    client = Client.objects.get(id=id_client)
    data={
        'id_client':id_client,
        'first_name':client.first_name,
        'last_name':client.last_name,
        'nit':client.nit,
        'dpi':client.dpi,
        'telephone':client.telephone,
        'address':client.address,
        'email':client.email,
    }
    return render(request, 'client/edit.html', data)

#Vista para eliminar un cliente.
def delete(request, id_client):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.delete_client(request, id_client)
    if cr:
        messages.success(request, 'Cliente eliminado correctamente!')
    else: 
        messages.error(request, '¡Error al eliminar al cliente!')
    return redirect('client') 