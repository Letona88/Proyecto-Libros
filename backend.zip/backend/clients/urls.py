from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from clients import views
from django.conf.urls import url

#url básicas para poder hacer un crud en clientes: mostrar, crear, editar, eliminar
urlpatterns=[
    path('', views.index, name='client'),
    path('create/', views.create,  name='create_client'),
    url(r'^edit/(?P<id_client>[\w.@+-]+)/$', views.edit,  name='edit_client'),
    url(r'^delete/(?P<id_client>[\w.@+-]+)/$', views.delete,  name='delete_client'),
]