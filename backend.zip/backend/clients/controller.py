from clients.models import Client
from django.core.files.storage import FileSystemStorage
import datetime

#Función para obtener a todos los clientes y retornarlo como un diccionario
def get_clients(request):
    response = []
    clients = Client.objects.all()

    response.append({
        "clients":clients
    })

    return response

#Funcion para creat un cliente.
def create_client(request):
    data = request.POST

    first_name = data.get('first_name')
    last_name = data.get('last_name')
    nit = data.get('nit')
    dpi = data.get('dpi')
    telephone = data.get('telephone')
    address = data.get('address')
    email = data.get('email')


    new_client = Client(
        first_name=first_name, 
        last_name=last_name, 
        nit=nit, 
        dpi=dpi,
        telephone=telephone,
        address=address,
        email=email,
    )
    new_client.save()

    if new_client:
        return True
    else:
        return False

#Funcion para editar un cliente
def edit_client(request,id_client):
    data = request.POST

    first_name=data.get('first_name')
    last_name=data.get('last_name')
    nit=data.get('nit')
    dpi=data.get('dpi')
    telephone=data.get('telephone')
    address=data.get('address')
    email=data.get('email')

    client=Client.objects.get(id=id_client)
    client.first_name=first_name
    client.last_name=last_name
    client.nit=nit
    client.dpi=dpi
    client.telephone=telephone
    client.address=address
    client.email=email
    client.save()

    if client:
        return True
    else:
        return False

#Funcion para eliminar un cliente.
def delete_client(request, id_client):
    client=Client.objects.get(id=id_client)
    if client:
        client.delete()
        return True
    else:
        return False