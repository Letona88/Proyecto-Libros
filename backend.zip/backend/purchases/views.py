from django.shortcuts import render, redirect
from purchases import controller
from django.contrib import messages
from purchases.models import Purchase
import datetime

#Funcion para mostrar las compras
def index(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_purchase(request)
    return render(request, 'purchase/index.html', cr[0])

#Funcion para crear una compra
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.create_purchase(request)
        if cr:
            messages.success(request, '¡Compra registrara correctamente!')
        else: 
            messages.error(request, '¡Error al registrar la compra!')
        return redirect('purchase') 

    return render(request, 'purchase/create.html')
