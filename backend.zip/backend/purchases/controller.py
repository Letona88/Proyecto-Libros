from purchases.models import Purchase
from products.models import Product
from inventories.models import Inventory
from django.core.files.storage import FileSystemStorage
import datetime

#Funcion para obtener las ventas y retornaras como un diccionario.
def get_purchase(request):
    response = []
    purchases = Purchase.objects.all()
    products = Product.objects.all()

    response.append({
        "purchases":purchases,
        "products":products
    })

    return response

#Funcion para crear una venta
def create_purchase(request):
    data=request.POST

    id_product=data.get('product')
    product=Product.objects.get(id=id_product)
    quantity=data.get('quantity')
    date_purchase=data.get('date')
    date_purchase=datetime.datetime.strptime(date_purchase, "%m/%d/%Y").strftime("%Y-%m-%d")


    new_purchase=Purchase(
        product=product, 
        date_purchase=date_purchase,
        quantity=quantity,
        total=float(quantity) * float(product.price),
    )
    new_purchase.save()

    #El producto se actualiza en la cantidad.
    product.quanty+=int(quantity)

    product.save()

    new_inventary=Inventory(
        product=product,
        content_object=new_purchase,
        date_action=date_purchase,
        quantity=quantity,
        total=float(quantity)*float(product.price)
    )

    new_inventary.save()

    if new_purchase:
        return True
    else:
        return False
