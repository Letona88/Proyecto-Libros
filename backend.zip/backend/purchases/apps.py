from django.apps import AppConfig


class PurchasesConfig(AppConfig):
    name = 'purchases'
