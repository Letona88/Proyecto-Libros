from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
#importación de la vista para acceder a lo necesario para ir a un template(archivo html)
from products import views
from django.conf.urls import url

#las diferentes rutas para un crud: mostrar, crear, editar, eliminar.
urlpatterns=[
    path('', views.index, name='product'),
    path('create/', views.create,  name='create_product'),
    url(r'^edit/(?P<id_product>[\w.@+-]+)/$', views.edit,  name='edit_product'),
    url(r'^delete/(?P<id_product>[\w.@+-]+)/$', views.delete,  name='delete_product'),
]