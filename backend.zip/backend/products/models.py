from django.db import models

class Product(models.Model):
    title = models.CharField(max_length=150)
    author = models.CharField(max_length=150, null=True, blank=True)
    chapters = models.IntegerField(null=True, blank=True)
    completion_date = models.DateField(null=True, blank=True)
    pages = models.IntegerField(null=True, blank=True)
    edition = models.CharField(max_length=150, null=True, blank=True)
    cover_page = models.ImageField(null=True, blank=True)
    quanty = models.IntegerField(null=True, blank=True)
    price = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)