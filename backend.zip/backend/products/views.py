from django.shortcuts import render, redirect
#Importación del controlador que no servirá para ejecutar la obtención de datos.
from products import controller
from django.contrib import messages
from products.models import Product
import datetime

# Create your views here.
#Vista para poder obtener los datos y mostrarlos en una tabla en el template
def index(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.get_products(request)
    return render(request, 'product/index.html', cr[0])

#vista para poder crear un nuevo producto o mostrar el template del formulario
#para poder ingresar los datos del nuevo archivo
def create(request):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.create_product(request)
        if cr:
            messages.success(request, '¡Producto creado correctamente!')
        else: 
            messages.error(request, '¡Error al crear el producto!')
        return redirect('product') 

    return render(request, 'product/create.html')

#vista para poder editar un producto o mostrar el template del formulario
#para poder editar los datos del producto
def edit(request, id_product):
    if not request.user.is_authenticated: 
        return redirect('login')
    if request.method == 'POST':
        cr = controller.edit_product(request,id_product)
        if cr:
            messages.success(request, '¡Producto editado correctamente!')
        else: 
            messages.error(request, '¡Error al editar el producto!')
        return redirect('product')
    product = Product.objects.get(id=id_product)
    completion_date = datetime.datetime.strptime(str(product.completion_date), "%Y-%m-%d").strftime("%m/%d/%Y")
    data={
        'id_product':id_product,
        'title':product.title,
        'author':product.author,
        'chapters':product.chapters,
        'pages':product.pages,
        'price':product.price,
        'completion_date':completion_date,
        'edition':product.edition,
    }
    return render(request, 'product/edit.html', data)

#Vista para poder eliminar un archivo.
def delete(request, id_product):
    if not request.user.is_authenticated: 
        return redirect('login')
    cr = controller.delete_product(request, id_product)
    if cr:
        messages.success(request, '¡Producto eliminado correctamente!')
    else: 
        messages.error(request, '¡Error al eliminar el producto!')
    return redirect('product') 