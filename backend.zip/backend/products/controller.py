#Se importa el modelo de Product para poder trabajar con este.
from products.models import Product
from django.core.files.storage import FileSystemStorage
import datetime

#se obtiene todos los productos registrados para mostrar en el template
def get_products(request):
    response = []
    products = Product.objects.all()

    response.append({
        "products":products
    })

    return response

#función para poder crear un nuevo producto.
def create_product(request):
    data = request.POST

    title = data.get('title')
    author = data.get('author')
    chapters = data.get('chapters')
    completion_date = data.get('completion_date')
    pages = data.get('pages')
    edition = data.get('edition')
    cover_page = request.FILES['cover_page']
    quanty = 0
    price = data.get('price')
    #se cambia el formato de la fecha de "mes/dia/año" a "año-mes-dia"
    completion_date = datetime.datetime.strptime(completion_date, "%m/%d/%Y").strftime("%Y-%m-%d")

    #se trae al modelo del producto y se agrega la información necesaria para crear un nuevo registro
    new_product = Product(
        title=title, 
        author=author, 
        chapters=chapters, 
        completion_date=completion_date,
        pages=pages,
        edition=edition,
        cover_page=cover_page,
        quanty=quanty,
        price=price
    )
    new_product.save()

    if new_product:
        return True
    else:
        return False

#Función para poder editar un producto
def edit_product(request,id_product):
    data = request.POST

    title=data.get('title')
    author=data.get('author')
    chapters=data.get('chapters')
    completion_date=data.get('completion_date')
    pages=data.get('pages')
    edition=data.get('edition')
    cover_page=request.FILES['cover_page'] if 'cover_page' in request.FILES else False
    price=data.get('price')
    completion_date=datetime.datetime.strptime(completion_date, "%m/%d/%Y").strftime("%Y-%m-%d")

    product=Product.objects.get(id=id_product)
    product.title=title
    product.author=author
    product.chapters=chapters
    product.completion_date=completion_date
    product.pages=pages
    product.edition=edition
    if cover_page:
        product.cover_page=cover_page
    product.price=price
    product.save()

    if product:
        return True
    else:
        return False
#función para eliminar el registro de un producto
def delete_product(request, id_product):
    product=Product.objects.get(id=id_product)
    if product:
        product.delete()
        return True
    else:
        return False